# Break-Reminder-App
A simple, useful app to remind users to take breaks by customizing the time and length of their breaks. Get regular break reminders through push notifications.
